package com.example.sameershekhar.petsearch.views;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import com.example.sameershekhar.petsearch.R;

public class HomeScreen extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
}
